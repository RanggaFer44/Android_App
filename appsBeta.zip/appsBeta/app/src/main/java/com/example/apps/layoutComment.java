package com.example.apps;

public class layoutComment {
    /*

    <LinearLayout
        android:layout_width="match_parent"
        android:layout_height="match_parent"
        android:orientation="vertical">

        <LinearLayout
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:orientation="vertical"
            android:layout_marginTop="20dp"
            android:padding="20dp">

            <TextView
                android:layout_width="250dp"
                android:layout_height="108dp"
                android:text="Greetings Young Blood"
                android:textAlignment="center"
                android:textColor="@color/white"
                android:textSize="32sp"
                android:layout_gravity="center"
                />

            <EditText
                android:id="@+id/signUpUsername"
                android:layout_width="350dp"
                android:layout_height="60dp"
                android:layout_gravity="center"
                android:layout_marginTop="50dp"
                android:background="@drawable/border"
                android:drawableLeft="@drawable/baseline_person_24"
                android:drawablePadding="8dp"
                android:hint="Username"
                android:padding="16dp"
                android:textSize="17dp" />

            <EditText
                android:layout_width="350dp"
                android:layout_height="60dp"
                android:id="@+id/signUpEmail"
                android:background="@drawable/border"
                android:layout_marginTop="20dp"
                android:padding="16dp"
                android:hint="Email"
                android:drawableLeft="@drawable/baseline_email_24"
                android:drawablePadding="8dp"
                android:textSize="17dp"
                android:layout_gravity="center"/>

            <EditText
                android:layout_width="350dp"
                android:layout_height="60dp"
                android:id="@+id/signUpPassword"
                android:background="@drawable/border"
                android:layout_marginTop="20dp"
                android:padding="16dp"
                android:hint="Password"
                android:drawableLeft="@drawable/baseline_password_24"
                android:drawablePadding="8dp"
                android:textSize="17dp"
                android:layout_gravity="center">
                            <requestFocus >
                        </EditText>

            <EditText
                android:layout_width="350dp"
                android:layout_height="60dp"
                android:id="@+id/confirmPassword"
                android:background="@drawable/border"
                android:layout_marginTop="20dp"
                android:padding="16dp"
                android:hint="Confirm Password"
                android:drawableLeft="@drawable/baseline_password_24"
                android:drawablePadding="8dp"
                android:textSize="17dp"
                android:layout_gravity="center">
                <requestFocus/>
            </EditText>

            <CheckBox
                android:id="@+id/ShowP"
                android:layout_width="wrap_content"
                android:layout_height="wrap_content"
                android:layout_gravity="right"
                android:layout_marginRight="20dp"
                android:layout_marginTop="20dp"
                android:text="Show Password"
                android:textColor="@color/white"
                />

            <Button
                android:id="@+id/SignupBtn"
                android:layout_height="50dp"
                android:layout_width="210dp"
                android:background="@drawable/border"
                android:backgroundTint="@color/Cadetblue"
                android:text="Sign Up"
                android:layout_gravity="center"
                android:layout_marginTop="10dp"
                />


            <Button
                android:id="@+id/loginRedirect"
                android:layout_width="200dp"
                android:layout_height="wrap_content"
                android:text="already have account"
                android:layout_gravity="center"
                android:background="@color/Cadetblue"
                android:padding="8dp"
                android:textSize="12sp"
                android:layout_marginTop="8dp"
                android:textColor="@color/black"/>


        </LinearLayout>

    </LinearLayout>

            */


}
